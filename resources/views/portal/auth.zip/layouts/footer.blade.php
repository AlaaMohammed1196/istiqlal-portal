<footer>
    <div class="footer-content">
        <div class="container">
            <div class="d-flex justify-content-between">
                <div class="col-12 col-sm-6">
                    <p class="mb-0 text-muted text-medium">© {{now()->year}} جميع الحقوق محفوظة لبنك الاستقلال للاستثمار و التنمية</p>
                </div>
                <div class="col-sm-6 d-none d-sm-block">
                    <ul class="breadcrumb pt-0 pe-0 mb-0 float-start">
                        <li class="breadcrumb-item mb-0 text-medium">
                            <a href="https://fis.ps" target="_blank" class="btn-link">fis.ps</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
