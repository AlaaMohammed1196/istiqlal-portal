@if(count($data['FUND_SOURCE_CUST_CONTR_DESC']) > 0)
    <?php $sum = 0; ?>
@foreach($data['FUND_SOURCE_CUST_CONTR_DESC'] as $index=>$item)
<tr id="desc-{{$item['SOURCE_CUST_CONTR_DESC_ID']}}">
    <th scope="row">{{$item['SOURCE_CUST_CONTR_DESC']}}</th>
    <td class="text-center">
        <?php $sum += $item['ANNUAL_SOURCE_VALUE'] ?>
        <span class="text-secondary">{{$item['ANNUAL_SOURCE_VALUE']}}</span>
    </td>
    <td class="text-center"><span class="">{{$item['CURR_NAME']}}</span></td>
    <td  class="text-center" width="15%">
        <button class="btn btn-sm btn-icon btn-icon-only btn-outline-dark align-top mx-2" type="button" data-key="{{$index}}" onclick="editFundDescRecord(this)">
            <i class="fa-solid fa-pen-to-square"></i>
        </button>
        <button class="btn btn-sm btn-icon btn-icon-only btn-outline-danger align-top" type="button" data-id="{{$item['SOURCE_CUST_CONTR_DESC_ID']}}" onclick="deleteFundDescRecord(this)">
            <i class="fa-solid fa-circle-xmark"></i>
        </button>
    </td>
</tr>
@endforeach
<tr  class="table-light">
    <th scope="row" class="table-light">المجموع</th>
    <td class="text-center table-light"><span class="text-secondary">{{$sum}}</span></td>
    <td class="text-center table-light"><span class=""></span></td>
    <td  class="text-center table-light" width="15%"></td>
</tr>
@endif
